/**
 * Sidebar component for the application
 */
class Sidebar {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    this.options = {
      defaultActive: '', // Current active page
      sections: [], // Sidebar sections to show
      ...options
    };
    this.render();
    this.setupEventListeners();
  }

  render() {
    if (!this.container) return;

    // Check if user is authenticated
    const isAuthenticated = window.authManager && window.authManager.isAuthenticated();
    
    // Default sections if none provided
    const defaultSections = [
      {
        title: 'Main',
        items: [
          { 
            id: 'dashboard', 
            label: 'Dashboard', 
            icon: 'th-large',
            href: '/dashboard.html',
            requiresAuth: true
          },
          { 
            id: 'subscription', 
            label: 'Subscription', 
            icon: 'crown',
            href: '/subscription.html',
            requiresAuth: true
          }
        ]
      },
      {
        title: 'Projects',
        items: [
          { 
            id: 'myprojects', 
            label: 'My Projects', 
            icon: 'folder',
            href: '/dashboard.html',
            requiresAuth: true
          },
          { 
            id: 'templates', 
            label: 'Templates', 
            icon: 'paint-brush',
            href: '/templates.html',
            requiresAuth: true
          }
        ]
      }
    ];

    // Use provided sections or defaults
    const sections = this.options.sections.length > 0 
      ? this.options.sections 
      : defaultSections;

    // Create sidebar HTML
    let sidebarHtml = `<div class="sidebar">`;

    // Add sections
    sections.forEach(section => {
      // Filter out items that require auth if user is not authenticated
      const visibleItems = section.items.filter(item => 
        !item.requiresAuth || isAuthenticated
      );

      // Skip empty sections
      if (visibleItems.length === 0) return;

      sidebarHtml += `
        <div class="sidebar-section">
          <h3 class="sidebar-section-title">${section.title}</h3>
          <div class="sidebar-nav">
      `;

      // Add section items
      visibleItems.forEach(item => {
        const isActive = item.id === this.options.defaultActive;
        sidebarHtml += `
          <a href="${item.href}" class="sidebar-link ${isActive ? 'active' : ''}" data-id="${item.id}">
            <i class="fas fa-${item.icon}"></i>
            <span>${item.label}</span>
          </a>
        `;
      });

      sidebarHtml += `
          </div>
        </div>
      `;
    });

    // Add sidebar toggle at the bottom
    sidebarHtml += `
      <div class="sidebar-section">
        <a href="#" class="sidebar-link sidebar-collapse-toggle">
          <i class="fas fa-chevron-left"></i>
          <span>Collapse Sidebar</span>
        </a>
      </div>
    `;

    sidebarHtml += `</div>`;

    // Set the HTML
    this.container.innerHTML = sidebarHtml;
  }

  setupEventListeners() {
    if (!this.container) return;

    // Sidebar collapse toggle
    const sidebarCollapseToggle = this.container.querySelector('.sidebar-collapse-toggle');
    const sidebar = this.container.querySelector('.sidebar');
    
    if (sidebarCollapseToggle && sidebar) {
      sidebarCollapseToggle.addEventListener('click', (e) => {
        e.preventDefault();
        
        // Toggle collapsed state
        sidebar.classList.toggle('sidebar-collapsed');
        
        // Update toggle text and icon
        if (sidebar.classList.contains('sidebar-collapsed')) {
          sidebarCollapseToggle.innerHTML = '<i class="fas fa-chevron-right"></i><span>Expand</span>';
        } else {
          sidebarCollapseToggle.innerHTML = '<i class="fas fa-chevron-left"></i><span>Collapse Sidebar</span>';
        }
      });
    }

    // Handle sidebar link clicks
    const sidebarLinks = this.container.querySelectorAll('.sidebar-link:not(.sidebar-collapse-toggle)');
    
    sidebarLinks.forEach(link => {
      link.addEventListener('click', () => {
        // Remove active class from all links
        sidebarLinks.forEach(l => l.classList.remove('active'));
        
        // Add active class to clicked link
        link.classList.add('active');
        
        // Update active item in options
        this.options.defaultActive = link.getAttribute('data-id');
      });
    });
  }

  setActive(itemId) {
    if (!this.container) return;

    // Update the active item
    this.options.defaultActive = itemId;
    
    // Update the UI
    const sidebarLinks = this.container.querySelectorAll('.sidebar-link');
    sidebarLinks.forEach(link => {
      if (link.getAttribute('data-id') === itemId) {
        link.classList.add('active');
      } else {
        link.classList.remove('active');
      }
    });
  }
}

// Export the component
window.Sidebar = Sidebar; 