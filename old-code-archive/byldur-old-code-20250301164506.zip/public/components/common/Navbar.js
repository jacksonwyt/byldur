/**
 * Navbar component for the application
 */
class Navbar {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    this.options = {
      showDashboardLink: true,
      showEditorActions: false,
      ...options
    };
    this.render();
    this.setupEventListeners();
  }

  render() {
    if (!this.container) return;

    // Check if user is authenticated
    const isAuthenticated = window.authManager && window.authManager.isAuthenticated();
    const user = window.authManager ? window.authManager.getUser() : null;
    
    // Get current theme
    const theme = window.themeManager ? window.themeManager.getTheme() : 'light';

    // Create navbar HTML
    const navbarHtml = `
      <nav class="navbar">
        <div class="navbar-brand">
          <a href="${isAuthenticated ? '/dashboard.html' : '/landing.html'}" class="navbar-brand">
            <img src="/assets/byldur-logo.svg" alt="Byldur" class="navbar-logo">
            <span class="hide-sm">Byldur</span>
          </a>
        </div>

        <div class="navbar-nav">
          ${isAuthenticated ? `
            ${this.options.showDashboardLink ? `
              <a href="/dashboard.html" class="navbar-link ${window.location.pathname === '/dashboard.html' ? 'active' : ''}">
                <i class="fas fa-th-large"></i> <span class="hide-sm">Dashboard</span>
              </a>
            ` : ''}
            <a href="/subscription.html" class="navbar-link ${window.location.pathname === '/subscription.html' ? 'active' : ''}">
              <i class="fas fa-crown"></i> <span class="hide-sm">Subscription</span>
            </a>
          ` : `
            <a href="/landing.html" class="navbar-link ${window.location.pathname === '/landing.html' ? 'active' : ''}">
              <i class="fas fa-home"></i> <span class="hide-sm">Home</span>
            </a>
            <a href="/landing.html#features" class="navbar-link">
              <i class="fas fa-star"></i> <span class="hide-sm">Features</span>
            </a>
            <a href="/landing.html#pricing" class="navbar-link">
              <i class="fas fa-tags"></i> <span class="hide-sm">Pricing</span>
            </a>
          `}
        </div>

        <div class="navbar-actions">
          ${this.options.showEditorActions ? `
            <button id="save-btn" class="btn btn-primary btn-sm">
              <i class="fa fa-save"></i> <span class="hide-sm">Save</span>
            </button>
            <button id="preview-btn" class="btn btn-outline btn-sm">
              <i class="fa fa-eye"></i> <span class="hide-sm">Preview</span>
            </button>
            <button id="publish-btn" class="btn btn-success btn-sm">
              <i class="fa fa-globe"></i> <span class="hide-sm">Publish</span>
            </button>
          ` : ''}

          <div class="theme-toggle" data-theme="${theme}">
            <i class="fas fa-sun"></i>
            <i class="fas fa-moon"></i>
            <span class="theme-toggle-thumb"></span>
          </div>

          ${isAuthenticated ? `
            <div class="dropdown">
              <button class="btn btn-outline btn-sm dropdown-toggle">
                <i class="fas fa-user"></i> <span class="hide-sm username-display">${user ? user.name : 'User'}</span>
              </button>
              <div class="dropdown-menu">
                <a href="/dashboard.html" class="dropdown-item">
                  <i class="fas fa-th-large"></i> Dashboard
                </a>
                <a href="/subscription.html" class="dropdown-item">
                  <i class="fas fa-crown"></i> Subscription
                </a>
                <div class="dropdown-divider"></div>
                <a href="#" class="dropdown-item logout-btn">
                  <i class="fas fa-sign-out-alt"></i> Logout
                </a>
              </div>
            </div>
          ` : `
            <a href="/login.html" class="btn btn-primary btn-sm">
              <i class="fas fa-sign-in-alt"></i> <span class="hide-sm">Login</span>
            </a>
          `}
          
          <button class="navbar-toggle">
            <i class="fas fa-bars"></i>
          </button>
        </div>
      </nav>
    `;

    // Set the HTML
    this.container.innerHTML = navbarHtml;
  }

  setupEventListeners() {
    if (!this.container) return;

    // Mobile menu toggle
    const navbarToggle = this.container.querySelector('.navbar-toggle');
    const navbarNav = this.container.querySelector('.navbar-nav');
    
    if (navbarToggle && navbarNav) {
      navbarToggle.addEventListener('click', () => {
        navbarNav.classList.toggle('show');
      });
    }

    // User dropdown
    const dropdownToggle = this.container.querySelector('.dropdown-toggle');
    const dropdownMenu = this.container.querySelector('.dropdown-menu');
    
    if (dropdownToggle && dropdownMenu) {
      dropdownToggle.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdownMenu.classList.toggle('show');
      });
      
      // Close dropdown when clicking outside
      document.addEventListener('click', () => {
        if (dropdownMenu.classList.contains('show')) {
          dropdownMenu.classList.remove('show');
        }
      });
    }

    // Editor action buttons
    if (this.options.showEditorActions) {
      const saveBtn = this.container.querySelector('#save-btn');
      const previewBtn = this.container.querySelector('#preview-btn');
      const publishBtn = this.container.querySelector('#publish-btn');
      
      if (saveBtn) {
        saveBtn.addEventListener('click', () => {
          // Dispatch a custom event for the editor to listen for
          const event = new CustomEvent('byldur:save');
          document.dispatchEvent(event);
        });
      }
      
      if (previewBtn) {
        previewBtn.addEventListener('click', () => {
          const event = new CustomEvent('byldur:preview');
          document.dispatchEvent(event);
        });
      }
      
      if (publishBtn) {
        publishBtn.addEventListener('click', () => {
          const event = new CustomEvent('byldur:publish');
          document.dispatchEvent(event);
        });
      }
    }
  }

  // Method to update the navbar when auth state changes
  updateAuthState() {
    this.render();
    this.setupEventListeners();
  }
}

// Export the component
window.Navbar = Navbar; 