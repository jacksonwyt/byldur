/**
 * AI Assistant component
 * Provides a chatbot-like interface for interacting with the AI assistant
 */
class AIAssistant {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    this.options = {
      initialMessage: "Hi! I'm your AI assistant. How can I help you build your website today?",
      showPremiumFeatures: true,
      ...options
    };
    
    this.state = {
      isOpen: false,
      messages: [],
      isProcessing: false,
      aiStatus: null
    };
    
    this.render();
    this.setupEventListeners();
    this.checkAISubscription();
  }
  
  render() {
    if (!this.container) return;
    
    // Create the floating button
    this.container.innerHTML = `
      <div class="ai-assistant" id="ai-assistant-button">
        <i class="fas fa-robot"></i>
      </div>
      
      <div class="ai-assistant-panel hidden" id="ai-assistant-panel">
        <div class="ai-assistant-header">
          <h3>AI Assistant</h3>
          <button class="ai-assistant-close" id="ai-assistant-close">
            <i class="fas fa-times"></i>
          </button>
        </div>
        
        <div class="ai-assistant-body" id="ai-assistant-messages">
          <!-- Messages will be added here -->
        </div>
        
        <div class="ai-assistant-footer">
          <input type="text" class="ai-assistant-input" id="ai-assistant-input" 
                 placeholder="Type your message..." ${this.state.aiStatus?.active ? '' : 'disabled'}>
          <button class="ai-assistant-send" id="ai-assistant-send" ${this.state.aiStatus?.active ? '' : 'disabled'}>
            <i class="fas fa-paper-plane"></i>
          </button>
        </div>
      </div>
    `;
    
    // Add welcome message
    this.addMessage({
      sender: 'assistant', 
      text: this.options.initialMessage
    });
    
    // If the user doesn't have an active AI subscription, show upgrade message
    if (this.state.aiStatus && !this.state.aiStatus.active) {
      this.addMessage({
        sender: 'assistant',
        text: `<div class="ai-upgrade-message">
                <p>Unlock the full power of AI assistance with a premium subscription!</p>
                <a href="/subscription.html" class="btn btn-primary">Upgrade Now</a>
              </div>`
      });
    }
  }
  
  setupEventListeners() {
    if (!this.container) return;
    
    const assistantButton = document.getElementById('ai-assistant-button');
    const assistantPanel = document.getElementById('ai-assistant-panel');
    const closeButton = document.getElementById('ai-assistant-close');
    const sendButton = document.getElementById('ai-assistant-send');
    const inputField = document.getElementById('ai-assistant-input');
    
    // Toggle assistant panel
    if (assistantButton && assistantPanel) {
      assistantButton.addEventListener('click', () => {
        this.togglePanel();
      });
    }
    
    // Close panel
    if (closeButton && assistantPanel) {
      closeButton.addEventListener('click', () => {
        this.togglePanel(false);
      });
    }
    
    // Send message
    if (sendButton && inputField) {
      sendButton.addEventListener('click', () => {
        this.sendMessage();
      });
      
      // Also send on Enter key
      inputField.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
          this.sendMessage();
        }
      });
    }
  }
  
  togglePanel(show) {
    const panel = document.getElementById('ai-assistant-panel');
    if (!panel) return;
    
    if (show === undefined) {
      show = panel.classList.contains('hidden');
    }
    
    if (show) {
      panel.classList.remove('hidden');
      this.state.isOpen = true;
      
      // Focus the input field
      const input = document.getElementById('ai-assistant-input');
      if (input && this.state.aiStatus?.active) {
        setTimeout(() => input.focus(), 300);
      }
    } else {
      panel.classList.add('hidden');
      this.state.isOpen = false;
    }
  }
  
  addMessage(message) {
    const messagesContainer = document.getElementById('ai-assistant-messages');
    if (!messagesContainer) return;
    
    // Create message element
    const messageElement = document.createElement('div');
    messageElement.className = `ai-message ai-message-${message.sender}`;
    messageElement.innerHTML = message.text;
    
    // Add to messages container
    messagesContainer.appendChild(messageElement);
    
    // Scroll to bottom
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    
    // Add to state
    this.state.messages.push(message);
  }
  
  sendMessage() {
    const inputField = document.getElementById('ai-assistant-input');
    if (!inputField || !inputField.value.trim() || this.state.isProcessing) return;
    
    const message = inputField.value.trim();
    
    // Add user message to chat
    this.addMessage({
      sender: 'user',
      text: message
    });
    
    // Clear input
    inputField.value = '';
    
    // Process the message
    this.processMessage(message);
  }
  
  async processMessage(message) {
    // Set processing state
    this.state.isProcessing = true;
    
    // Add loading indicator
    const messagesContainer = document.getElementById('ai-assistant-messages');
    const loadingEl = document.createElement('div');
    loadingEl.className = 'ai-message ai-message-assistant ai-message-loading';
    loadingEl.innerHTML = `<div class="spinner"></div>`;
    messagesContainer.appendChild(loadingEl);
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
    
    try {
      // Call the AI API
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${window.authManager.getToken()}`
        },
        body: JSON.stringify({ message })
      });
      
      if (!response.ok) {
        throw new Error('Failed to get AI response');
      }
      
      const data = await response.json();
      
      // Remove loading indicator
      messagesContainer.removeChild(loadingEl);
      
      // Add AI response
      this.addMessage({
        sender: 'assistant',
        text: data.response
      });
    } catch (error) {
      console.error('AI processing error:', error);
      
      // Remove loading indicator
      messagesContainer.removeChild(loadingEl);
      
      // Add error message
      this.addMessage({
        sender: 'assistant',
        text: "I'm sorry, I couldn't process your request. Please try again later."
      });
    } finally {
      this.state.isProcessing = false;
    }
  }
  
  async checkAISubscription() {
    if (!window.authManager || !window.authManager.isAuthenticated()) {
      return;
    }
    
    try {
      const response = await fetch('/api/subscriptions/ai-status', {
        headers: {
          'Authorization': `Bearer ${window.authManager.getToken()}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to check AI subscription');
      }
      
      const aiStatus = await response.json();
      this.state.aiStatus = aiStatus;
      
      // Update UI based on subscription status
      const inputField = document.getElementById('ai-assistant-input');
      const sendButton = document.getElementById('ai-assistant-send');
      
      if (inputField && sendButton) {
        if (aiStatus.active) {
          inputField.disabled = false;
          sendButton.disabled = false;
        } else {
          inputField.disabled = true;
          sendButton.disabled = true;
          
          // Show upgrade message if not already shown
          if (this.state.messages.length === 1) {
            this.addMessage({
              sender: 'assistant',
              text: `<div class="ai-upgrade-message">
                      <p>Unlock the full power of AI assistance with a premium subscription!</p>
                      <a href="/subscription.html" class="btn btn-primary">Upgrade Now</a>
                    </div>`
            });
          }
        }
      }
    } catch (error) {
      console.error('Error checking AI subscription:', error);
    }
  }
}

// Export the component
window.AIAssistant = AIAssistant; 