/**
 * AIStatusDisplay Component
 * Displays the user's AI subscription status on the dashboard
 */
class AIStatusDisplay {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    this.options = {
      loadingMessage: 'Checking AI subscription status...',
      ...options
    };
    
    this.state = {
      isLoading: true,
      status: null,
      error: null
    };
    
    this.render();
    this.fetchStatus();
  }
  
  render() {
    if (!this.container) return;
    
    if (this.state.isLoading) {
      this.container.innerHTML = `
        <div class="ai-status-loading">
          <div class="spinner"></div>
          <p>${this.options.loadingMessage}</p>
        </div>
      `;
      return;
    }
    
    if (this.state.error) {
      this.container.innerHTML = `
        <div class="ai-status-error">
          <i class="fas fa-exclamation-circle"></i>
          <p>There was an error checking your AI subscription status.</p>
          <button class="btn btn-primary retry-btn">
            <i class="fas fa-sync"></i> Retry
          </button>
        </div>
      `;
      
      // Add retry button event listener
      const retryBtn = this.container.querySelector('.retry-btn');
      if (retryBtn) {
        retryBtn.addEventListener('click', () => {
          this.state.isLoading = true;
          this.render();
          this.fetchStatus();
        });
      }
      
      return;
    }
    
    const { active, plan, usageCount, usageLimit, expiresAt } = this.state.status;
    const usagePercentage = usageLimit ? Math.min(100, Math.round((usageCount / usageLimit) * 100)) : 0;
    
    let expiryInfo = '';
    if (expiresAt) {
      const expiryDate = new Date(expiresAt);
      expiryInfo = `Expires on ${expiryDate.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      })}`;
    }
    
    let statusHtml = '';
    
    if (active) {
      statusHtml = `
        <div class="ai-status status-active">
          <div class="status-header">
            <h2><i class="fas fa-robot"></i> AI Assistant - Active</h2>
            <span class="badge badge-success">Active</span>
          </div>
          
          <div class="status-details">
            <p class="plan-name">${plan || 'Premium'} Plan</p>
            ${expiryInfo ? `<p class="expiry-info">${expiryInfo}</p>` : ''}
            
            <div class="usage-info">
              <p>Usage: ${usageCount} / ${usageLimit || 'Unlimited'} AI operations</p>
              <div class="usage-meter">
                <div class="usage-bar" style="width: ${usagePercentage}%"></div>
              </div>
            </div>
            
            <div class="ai-actions">
              <a href="/editor.html" class="btn btn-primary">
                <i class="fas fa-pencil-alt"></i> Create with AI
              </a>
              <a href="/subscription.html" class="btn btn-outline">
                <i class="fas fa-crown"></i> Manage Subscription
              </a>
            </div>
          </div>
        </div>
      `;
    } else {
      statusHtml = `
        <div class="ai-status status-inactive">
          <div class="status-header">
            <h2><i class="fas fa-robot"></i> AI Assistant - Inactive</h2>
            <span class="badge badge-secondary">Inactive</span>
          </div>
          
          <div class="status-details">
            <p>Enhance your website building with AI assistance!</p>
            
            <div class="ai-features">
              <div class="feature-item">
                <i class="fas fa-magic"></i>
                <p>Generate content for your website with one click</p>
              </div>
              <div class="feature-item">
                <i class="fas fa-palette"></i>
                <p>Get AI-powered design suggestions</p>
              </div>
              <div class="feature-item">
                <i class="fas fa-bolt"></i>
                <p>Build websites faster with AI assistance</p>
              </div>
            </div>
            
            <div class="ai-actions">
              <a href="/subscription.html" class="btn btn-primary">
                <i class="fas fa-crown"></i> Upgrade Now
              </a>
              <a href="/editor.html" class="btn btn-outline">
                <i class="fas fa-external-link-alt"></i> Try Basic Editor
              </a>
            </div>
          </div>
        </div>
      `;
    }
    
    this.container.innerHTML = statusHtml;
  }
  
  async fetchStatus() {
    try {
      // Check if user is authenticated
      if (!window.authManager || !window.authManager.isAuthenticated()) {
        this.state.isLoading = false;
        this.state.error = new Error('User not authenticated');
        this.render();
        return;
      }
      
      const response = await fetch('/api/subscriptions/ai-status', {
        headers: {
          'Authorization': `Bearer ${window.authManager.getToken()}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch AI subscription status');
      }
      
      const data = await response.json();
      
      this.state.status = data;
      this.state.isLoading = false;
      this.render();
    } catch (error) {
      console.error('Error fetching AI status:', error);
      this.state.error = error;
      this.state.isLoading = false;
      this.render();
    }
  }
}

// Export the component
window.AIStatusDisplay = AIStatusDisplay; 