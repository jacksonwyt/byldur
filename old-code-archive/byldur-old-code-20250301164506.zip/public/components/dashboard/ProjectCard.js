/**
 * ProjectCard Component
 * Displays a project in the dashboard
 */
class ProjectCard {
  constructor(project, options = {}) {
    this.project = project;
    this.options = {
      onEdit: null,
      onDelete: null,
      onDuplicate: null,
      ...options
    };
  }
  
  render() {
    const { id, name, description, thumbnail, updatedAt, publishedUrl } = this.project;
    const formattedDate = new Date(updatedAt).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
    
    return `
      <div class="card project-card" data-project-id="${id}">
        <div class="project-thumbnail">
          ${thumbnail 
            ? `<img src="${thumbnail}" alt="${name}" class="project-image">`
            : `<div class="project-image-placeholder">
                 <i class="fas fa-file-alt"></i>
               </div>`
          }
        </div>
        
        <div class="card-body">
          <h3 class="project-title">${name}</h3>
          <p class="project-description">${description || 'No description provided'}</p>
          
          <div class="project-meta">
            <span class="project-date">
              <i class="fas fa-clock"></i> ${formattedDate}
            </span>
            ${publishedUrl ? `
              <span class="project-status published">
                <i class="fas fa-globe"></i> Published
              </span>
            ` : `
              <span class="project-status draft">
                <i class="fas fa-pencil-alt"></i> Draft
              </span>
            `}
          </div>
        </div>
        
        <div class="card-footer">
          <div class="project-actions">
            <button class="btn btn-primary btn-sm edit-project-btn" data-project-id="${id}">
              <i class="fas fa-edit"></i> Edit
            </button>
            
            <button class="btn btn-outline btn-sm project-menu-toggle" data-project-id="${id}">
              <i class="fas fa-ellipsis-v"></i>
            </button>
            
            <div class="project-menu hidden" data-project-id="${id}">
              ${publishedUrl ? `
                <a href="${publishedUrl}" class="project-menu-item" target="_blank">
                  <i class="fas fa-external-link-alt"></i> View Live
                </a>
              ` : ''}
              
              <button class="project-menu-item duplicate-project-btn" data-project-id="${id}">
                <i class="fas fa-copy"></i> Duplicate
              </button>
              
              <button class="project-menu-item delete-project-btn" data-project-id="${id}">
                <i class="fas fa-trash-alt"></i> Delete
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
  }
  
  static setupEventListeners() {
    // Setup edit button click
    document.querySelectorAll('.edit-project-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const projectId = e.currentTarget.getAttribute('data-project-id');
        window.location.href = `/editor.html?id=${projectId}`;
      });
    });
    
    // Setup menu toggle
    document.querySelectorAll('.project-menu-toggle').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const projectId = e.currentTarget.getAttribute('data-project-id');
        const menu = document.querySelector(`.project-menu[data-project-id="${projectId}"]`);
        
        // Close all other menus first
        document.querySelectorAll('.project-menu').forEach(m => {
          if (m !== menu) m.classList.add('hidden');
        });
        
        // Toggle this menu
        menu.classList.toggle('hidden');
        
        // Stop propagation to prevent document click handler from closing it immediately
        e.stopPropagation();
      });
    });
    
    // Setup duplicate button click
    document.querySelectorAll('.duplicate-project-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const projectId = e.currentTarget.getAttribute('data-project-id');
        
        try {
          const response = await fetch(`/api/projects/${projectId}/duplicate`, {
            method: 'POST',
            headers: {
              'Authorization': `Bearer ${window.authManager.getToken()}`
            }
          });
          
          if (!response.ok) {
            throw new Error('Failed to duplicate project');
          }
          
          const result = await response.json();
          
          // Refresh the dashboard
          window.location.reload();
        } catch (error) {
          console.error('Error duplicating project:', error);
          alert('Failed to duplicate project. Please try again.');
        }
      });
    });
    
    // Setup delete button click
    document.querySelectorAll('.delete-project-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        const projectId = e.currentTarget.getAttribute('data-project-id');
        
        if (confirm('Are you sure you want to delete this project? This action cannot be undone.')) {
          try {
            const response = await fetch(`/api/projects/${projectId}`, {
              method: 'DELETE',
              headers: {
                'Authorization': `Bearer ${window.authManager.getToken()}`
              }
            });
            
            if (!response.ok) {
              throw new Error('Failed to delete project');
            }
            
            // Remove the card from the UI
            const card = document.querySelector(`.project-card[data-project-id="${projectId}"]`);
            if (card) {
              card.remove();
            }
          } catch (error) {
            console.error('Error deleting project:', error);
            alert('Failed to delete project. Please try again.');
          }
        }
      });
    });
    
    // Close menus when clicking elsewhere
    document.addEventListener('click', () => {
      document.querySelectorAll('.project-menu').forEach(menu => {
        menu.classList.add('hidden');
      });
    });
  }
}

// Export the component
window.ProjectCard = ProjectCard; 