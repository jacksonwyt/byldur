/**
 * PlanCard Component
 * Displays a subscription plan in the subscription page
 */
class PlanCard {
  constructor(plan, options = {}) {
    this.plan = plan;
    this.options = {
      currentPlan: null,
      onSelect: null,
      ...options
    };
  }
  
  render() {
    const { id, name, price, features, recommended, ai_credits, highlighted } = this.plan;
    const isCurrent = this.options.currentPlan && this.options.currentPlan.id === id;
    
    return `
      <div class="card plan-card ${recommended ? 'featured' : ''} ${highlighted ? 'highlighted' : ''}" data-plan-id="${id}">
        ${recommended ? `<div class="plan-tag">Recommended</div>` : ''}
        ${isCurrent ? `<div class="plan-tag current">Current Plan</div>` : ''}
        
        <div class="plan-header">
          <h3>${name}</h3>
        </div>
        
        <div class="plan-price">
          $${price}<span>/month</span>
        </div>
        
        <div class="plan-features">
          <ul>
            ${features.map(feature => `
              <li>
                <i class="fas fa-check"></i> ${feature}
              </li>
            `).join('')}
            
            ${ai_credits ? `
              <li class="feature-highlight">
                <i class="fas fa-robot"></i> <strong>${ai_credits} AI Credits</strong>
              </li>
            ` : ''}
          </ul>
        </div>
        
        <div class="plan-action">
          ${isCurrent ? `
            <button class="btn btn-outline w-100" disabled>Current Plan</button>
          ` : `
            <button class="btn btn-primary w-100 select-plan-btn" data-plan-id="${id}">
              ${price > 0 ? 'Subscribe Now' : 'Start Free'}
            </button>
          `}
        </div>
      </div>
    `;
  }
  
  static setupEventListeners(options = {}) {
    const { onSelect } = options;
    
    // Setup plan selection
    document.querySelectorAll('.select-plan-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const planId = e.currentTarget.getAttribute('data-plan-id');
        
        if (typeof onSelect === 'function') {
          onSelect(planId);
        }
      });
    });
  }
}

// Export the component
window.PlanCard = PlanCard; 