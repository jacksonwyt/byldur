/**
 * SubscriptionManager Component
 * Manages the subscription page and handles subscription-related actions
 */
class SubscriptionManager {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    this.options = {
      onSubscriptionChange: null,
      showPaymentForm: true,
      ...options
    };
    
    this.state = {
      isLoading: true,
      currentSubscription: null,
      availablePlans: [],
      selectedPlan: null,
      showPaymentForm: false,
      isProcessing: false,
      error: null
    };
    
    // Initialize the component
    this.render();
    this.fetchSubscriptionData();
  }
  
  render() {
    if (!this.container) return;
    
    if (this.state.isLoading) {
      this.container.innerHTML = `
        <div class="subscription-loading">
          <div class="spinner"></div>
          <p>Loading subscription information...</p>
        </div>
      `;
      return;
    }
    
    if (this.state.error) {
      this.container.innerHTML = `
        <div class="subscription-error">
          <div class="alert alert-danger">
            <i class="fas fa-exclamation-triangle"></i>
            <p>${this.state.error}</p>
          </div>
          <button class="btn btn-primary retry-btn">
            <i class="fas fa-sync"></i> Retry
          </button>
        </div>
      `;
      
      // Add retry button event listener
      const retryBtn = this.container.querySelector('.retry-btn');
      if (retryBtn) {
        retryBtn.addEventListener('click', () => {
          this.state.isLoading = true;
          this.render();
          this.fetchSubscriptionData();
        });
      }
      
      return;
    }
    
    // Create subscription page content
    let subscriptionHtml = `
      <div class="subscription-container">
        <div class="subscription-header">
          <h1>Subscription Plans</h1>
          <p>Choose the perfect plan for your needs</p>
        </div>
        
        ${this.state.currentSubscription ? `
          <div class="current-subscription">
            <div class="alert alert-info">
              <div class="flex items-center justify-between">
                <div>
                  <h3 class="m-0">Current Plan: ${this.state.currentSubscription.plan.name}</h3>
                  <p class="mb-sm">
                    ${this.getSubscriptionStatusText()}
                  </p>
                </div>
                ${this.state.currentSubscription.canceledAt ? `
                  <button class="btn btn-primary reactivate-btn">
                    <i class="fas fa-redo"></i> Reactivate Subscription
                  </button>
                ` : `
                  <button class="btn btn-outline cancel-btn">
                    <i class="fas fa-times"></i> Cancel Subscription
                  </button>
                `}
              </div>
            </div>
          </div>
        ` : ''}
        
        <div class="plans-container">
          <div class="row">
            ${this.renderPlans()}
          </div>
        </div>
        
        ${this.state.showPaymentForm ? this.renderPaymentForm() : ''}
      </div>
    `;
    
    this.container.innerHTML = subscriptionHtml;
    this.setupEventListeners();
  }
  
  renderPlans() {
    if (!this.state.availablePlans || this.state.availablePlans.length === 0) {
      return `
        <div class="col-12">
          <div class="alert alert-warning">
            <i class="fas fa-exclamation-circle"></i>
            <p>No subscription plans are currently available.</p>
          </div>
        </div>
      `;
    }
    
    // Create plan cards
    return this.state.availablePlans.map(plan => {
      const planCard = new PlanCard(plan, {
        currentPlan: this.state.currentSubscription ? this.state.currentSubscription.plan : null
      });
      
      return `
        <div class="col-md-4 col-sm-6 col-12">
          ${planCard.render()}
        </div>
      `;
    }).join('');
  }
  
  renderPaymentForm() {
    if (!this.state.selectedPlan) return '';
    
    const plan = this.state.availablePlans.find(p => p.id === this.state.selectedPlan);
    
    return `
      <div class="payment-form-container ${this.state.showPaymentForm ? '' : 'hidden'}">
        <div class="card">
          <div class="card-header">
            <h2>Complete Your Subscription</h2>
            <p>You're subscribing to the ${plan ? plan.name : ''} plan</p>
          </div>
          
          <div class="card-body">
            <form id="payment-form">
              <div class="payment-summary">
                <div class="flex justify-between">
                  <span>Plan:</span>
                  <span>${plan ? plan.name : ''}</span>
                </div>
                <div class="flex justify-between">
                  <span>Price:</span>
                  <span>$${plan ? plan.price : 0}/month</span>
                </div>
              </div>
              
              <div class="form-group">
                <label class="form-label">Card Information</label>
                <div id="card-element" class="form-input">
                  <!-- Stripe Card Element will be inserted here -->
                </div>
                <div id="card-errors" class="form-error" role="alert"></div>
              </div>
              
              <div class="form-actions">
                <button type="button" class="btn btn-outline cancel-payment-btn">
                  Cancel
                </button>
                <button type="submit" class="btn btn-primary submit-payment-btn" ${this.state.isProcessing ? 'disabled' : ''}>
                  ${this.state.isProcessing ? '<div class="spinner"></div> Processing...' : 'Subscribe Now'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    `;
  }
  
  setupEventListeners() {
    // Setup plan selection
    PlanCard.setupEventListeners({
      onSelect: (planId) => this.selectPlan(planId)
    });
    
    // Setup payment form cancel button
    const cancelPaymentBtn = this.container.querySelector('.cancel-payment-btn');
    if (cancelPaymentBtn) {
      cancelPaymentBtn.addEventListener('click', () => {
        this.state.showPaymentForm = false;
        this.state.selectedPlan = null;
        this.render();
      });
    }
    
    // Setup payment form submission
    const paymentForm = this.container.querySelector('#payment-form');
    if (paymentForm) {
      paymentForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.processPayment();
      });
    }
    
    // Setup cancel subscription button
    const cancelBtn = this.container.querySelector('.cancel-btn');
    if (cancelBtn) {
      cancelBtn.addEventListener('click', () => {
        if (confirm('Are you sure you want to cancel your subscription? Your benefits will continue until the end of the current billing period.')) {
          this.cancelSubscription();
        }
      });
    }
    
    // Setup reactivate subscription button
    const reactivateBtn = this.container.querySelector('.reactivate-btn');
    if (reactivateBtn) {
      reactivateBtn.addEventListener('click', () => {
        this.reactivateSubscription();
      });
    }
  }
  
  async fetchSubscriptionData() {
    try {
      // Check authentication
      if (!window.authManager || !window.authManager.isAuthenticated()) {
        throw new Error('You must be logged in to view subscription information');
      }
      
      // Fetch current subscription
      const subscriptionResponse = await fetch('/api/subscriptions/current', {
        headers: {
          'Authorization': `Bearer ${window.authManager.getToken()}`
        }
      });
      
      if (!subscriptionResponse.ok) {
        throw new Error('Failed to fetch subscription information');
      }
      
      const subscriptionData = await subscriptionResponse.json();
      this.state.currentSubscription = subscriptionData;
      
      // Fetch available plans
      const plansResponse = await fetch('/api/subscriptions/plans', {
        headers: {
          'Authorization': `Bearer ${window.authManager.getToken()}`
        }
      });
      
      if (!plansResponse.ok) {
        throw new Error('Failed to fetch subscription plans');
      }
      
      const plansData = await plansResponse.json();
      this.state.availablePlans = plansData;
      
      // Update state
      this.state.isLoading = false;
      this.state.error = null;
      this.render();
    } catch (error) {
      console.error('Subscription data fetch error:', error);
      this.state.isLoading = false;
      this.state.error = error.message || 'Failed to load subscription information';
      this.render();
    }
  }
  
  selectPlan(planId) {
    this.state.selectedPlan = planId;
    
    // Find the selected plan
    const plan = this.state.availablePlans.find(p => p.id === planId);
    
    // If it's a free plan, process it directly
    if (plan && plan.price === 0) {
      this.processFreePlan(planId);
      return;
    }
    
    // Otherwise show payment form
    this.state.showPaymentForm = true;
    this.render();
    
    // Initialize Stripe elements if needed
    this.initializeStripeElements();
  }
  
  async processFreePlan(planId) {
    try {
      this.state.isProcessing = true;
      this.render();
      
      const response = await fetch('/api/subscriptions/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${window.authManager.getToken()}`
        },
        body: JSON.stringify({ planId })
      });
      
      if (!response.ok) {
        throw new Error('Failed to subscribe to plan');
      }
      
      // Refresh subscription data
      this.state.isProcessing = false;
      this.state.selectedPlan = null;
      this.state.isLoading = true;
      this.render();
      this.fetchSubscriptionData();
      
      // Notify subscription change
      if (typeof this.options.onSubscriptionChange === 'function') {
        this.options.onSubscriptionChange(planId);
      }
    } catch (error) {
      console.error('Free plan subscription error:', error);
      this.state.isProcessing = false;
      this.state.error = error.message || 'Failed to subscribe to plan';
      this.render();
    }
  }
  
  initializeStripeElements() {
    // This is a placeholder for Stripe Elements initialization
    // In a real implementation, you would include the Stripe.js script
    // and initialize the card element here
    console.log('Initializing Stripe Elements (placeholder)');
  }
  
  async processPayment() {
    try {
      this.state.isProcessing = true;
      this.render();
      
      // This is a placeholder for Stripe payment processing
      // In a real implementation, you would collect the card details,
      // create a payment method, and then call your API
      console.log('Processing payment for plan:', this.state.selectedPlan);
      
      // Simulate API call
      const response = await fetch('/api/subscriptions/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${window.authManager.getToken()}`
        },
        body: JSON.stringify({ 
          planId: this.state.selectedPlan,
          // paymentMethodId would come from Stripe in a real implementation
          paymentMethodId: 'pm_placeholder'
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to process subscription payment');
      }
      
      // Refresh subscription data
      this.state.isProcessing = false;
      this.state.selectedPlan = null;
      this.state.showPaymentForm = false;
      this.state.isLoading = true;
      this.render();
      this.fetchSubscriptionData();
      
      // Notify subscription change
      if (typeof this.options.onSubscriptionChange === 'function') {
        this.options.onSubscriptionChange(this.state.selectedPlan);
      }
    } catch (error) {
      console.error('Payment processing error:', error);
      this.state.isProcessing = false;
      this.state.error = error.message || 'Failed to process payment';
      this.render();
    }
  }
  
  async cancelSubscription() {
    try {
      this.state.isProcessing = true;
      this.render();
      
      const response = await fetch('/api/subscriptions/cancel', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${window.authManager.getToken()}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to cancel subscription');
      }
      
      // Refresh subscription data
      this.state.isProcessing = false;
      this.state.isLoading = true;
      this.render();
      this.fetchSubscriptionData();
      
      // Notify subscription change
      if (typeof this.options.onSubscriptionChange === 'function') {
        this.options.onSubscriptionChange(null);
      }
    } catch (error) {
      console.error('Subscription cancellation error:', error);
      this.state.isProcessing = false;
      this.state.error = error.message || 'Failed to cancel subscription';
      this.render();
    }
  }
  
  async reactivateSubscription() {
    try {
      this.state.isProcessing = true;
      this.render();
      
      const response = await fetch('/api/subscriptions/reactivate', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${window.authManager.getToken()}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to reactivate subscription');
      }
      
      // Refresh subscription data
      this.state.isProcessing = false;
      this.state.isLoading = true;
      this.render();
      this.fetchSubscriptionData();
      
      // Notify subscription change
      if (typeof this.options.onSubscriptionChange === 'function') {
        this.options.onSubscriptionChange(this.state.currentSubscription?.plan?.id);
      }
    } catch (error) {
      console.error('Subscription reactivation error:', error);
      this.state.isProcessing = false;
      this.state.error = error.message || 'Failed to reactivate subscription';
      this.render();
    }
  }
  
  getSubscriptionStatusText() {
    const sub = this.state.currentSubscription;
    if (!sub) return '';
    
    if (sub.canceledAt) {
      const endDate = new Date(sub.currentPeriodEnd);
      return `Your subscription has been canceled and will end on ${endDate.toLocaleDateString()}`;
    }
    
    if (sub.status === 'active') {
      const renewDate = new Date(sub.currentPeriodEnd);
      return `Your subscription will renew on ${renewDate.toLocaleDateString()}`;
    }
    
    if (sub.status === 'trialing') {
      const endDate = new Date(sub.currentPeriodEnd);
      return `Your free trial ends on ${endDate.toLocaleDateString()}`;
    }
    
    if (sub.status === 'past_due') {
      return 'Your payment is past due. Please update your payment method.';
    }
    
    return `Subscription status: ${sub.status}`;
  }
}

// Export the component
window.SubscriptionManager = SubscriptionManager; 