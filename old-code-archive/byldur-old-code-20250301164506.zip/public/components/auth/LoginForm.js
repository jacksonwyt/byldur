/**
 * LoginForm Component
 * Handles user login
 */
class LoginForm {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    this.options = {
      showRegisterTab: true,
      redirectUrl: '/dashboard.html',
      onLogin: null,
      ...options
    };
    
    this.state = {
      isLoggingIn: false,
      isRegistering: false,
      activeTab: 'login',
      loginError: null,
      registerError: null
    };
    
    this.render();
    this.setupEventListeners();
    this.checkRedirectParam();
  }
  
  render() {
    if (!this.container) return;
    
    // Get redirect URL from options or query params
    const urlParams = new URLSearchParams(window.location.search);
    const redirectUrl = urlParams.get('redirect') || this.options.redirectUrl;
    
    // Check if there's already a token, if so redirect
    if (window.authManager && window.authManager.isAuthenticated()) {
      window.location.href = redirectUrl;
      return;
    }
    
    // Create the login form HTML
    const loginHtml = `
      <div class="card login-card">
        <div class="card-header text-center">
          <img src="/assets/byldur-logo.svg" alt="Byldur" class="login-logo">
          <h2>Welcome to Byldur</h2>
        </div>
        
        ${this.options.showRegisterTab ? `
          <div class="tabs">
            <button class="tab ${this.state.activeTab === 'login' ? 'active' : ''}" data-tab="login">
              Sign In
            </button>
            <button class="tab ${this.state.activeTab === 'register' ? 'active' : ''}" data-tab="register">
              Create Account
            </button>
          </div>
        ` : ''}
        
        <div class="tab-content ${this.state.activeTab === 'login' ? 'active' : ''}" id="login-tab">
          <form id="login-form">
            ${this.state.loginError ? `
              <div class="alert alert-danger">
                ${this.state.loginError}
              </div>
            ` : ''}
            
            <div class="form-group">
              <label class="form-label" for="login-email">Email Address</label>
              <input type="email" id="login-email" class="form-input" required>
            </div>
            
            <div class="form-group">
              <label class="form-label" for="login-password">Password</label>
              <input type="password" id="login-password" class="form-input" required>
            </div>
            
            <button type="submit" class="btn btn-primary login-btn w-100" ${this.state.isLoggingIn ? 'disabled' : ''}>
              ${this.state.isLoggingIn ? '<div class="spinner"></div> Signing In...' : 'Sign In'}
            </button>
          </form>
          
          <div class="form-footer text-center">
            <p>Don't have an account? <a href="#" class="register-link">Create one</a></p>
          </div>
        </div>
        
        ${this.options.showRegisterTab ? `
          <div class="tab-content ${this.state.activeTab === 'register' ? 'active' : ''}" id="register-tab">
            <form id="register-form">
              ${this.state.registerError ? `
                <div class="alert alert-danger">
                  ${this.state.registerError}
                </div>
              ` : ''}
              
              <div class="form-group">
                <label class="form-label" for="register-name">Full Name</label>
                <input type="text" id="register-name" class="form-input" required>
              </div>
              
              <div class="form-group">
                <label class="form-label" for="register-email">Email Address</label>
                <input type="email" id="register-email" class="form-input" required>
              </div>
              
              <div class="form-group">
                <label class="form-label" for="register-password">Password</label>
                <input type="password" id="register-password" class="form-input" required 
                       minlength="8" pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).*$"
                       title="Password must be at least 8 characters and include uppercase, lowercase, and numbers">
                <small class="form-text text-muted">
                  Password must be at least 8 characters and include uppercase, lowercase, and numbers
                </small>
              </div>
              
              <button type="submit" class="btn btn-primary register-btn w-100" ${this.state.isRegistering ? 'disabled' : ''}>
                ${this.state.isRegistering ? '<div class="spinner"></div> Creating Account...' : 'Create Account'}
              </button>
            </form>
            
            <div class="form-footer text-center">
              <p>Already have an account? <a href="#" class="login-link">Sign in</a></p>
            </div>
          </div>
        ` : ''}
      </div>
    `;
    
    this.container.innerHTML = loginHtml;
  }
  
  setupEventListeners() {
    if (!this.container) return;
    
    // Tab switching
    const tabs = this.container.querySelectorAll('.tab');
    tabs.forEach(tab => {
      tab.addEventListener('click', (e) => {
        const tabName = e.currentTarget.getAttribute('data-tab');
        this.switchTab(tabName);
      });
    });
    
    // Alternative tab switching via links
    const registerLink = this.container.querySelector('.register-link');
    const loginLink = this.container.querySelector('.login-link');
    
    if (registerLink) {
      registerLink.addEventListener('click', (e) => {
        e.preventDefault();
        this.switchTab('register');
      });
    }
    
    if (loginLink) {
      loginLink.addEventListener('click', (e) => {
        e.preventDefault();
        this.switchTab('login');
      });
    }
    
    // Login form submission
    const loginForm = this.container.querySelector('#login-form');
    if (loginForm) {
      loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleLogin();
      });
    }
    
    // Register form submission
    const registerForm = this.container.querySelector('#register-form');
    if (registerForm) {
      registerForm.addEventListener('submit', (e) => {
        e.preventDefault();
        this.handleRegister();
      });
    }
  }
  
  switchTab(tabName) {
    if (!['login', 'register'].includes(tabName)) return;
    
    this.state.activeTab = tabName;
    
    // Update UI
    const tabs = this.container.querySelectorAll('.tab');
    const tabContents = this.container.querySelectorAll('.tab-content');
    
    tabs.forEach(tab => {
      if (tab.getAttribute('data-tab') === tabName) {
        tab.classList.add('active');
      } else {
        tab.classList.remove('active');
      }
    });
    
    tabContents.forEach(content => {
      if (content.id === `${tabName}-tab`) {
        content.classList.add('active');
      } else {
        content.classList.remove('active');
      }
    });
  }
  
  async handleLogin() {
    // Get form values
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    
    // Validate
    if (!email || !password) {
      this.state.loginError = 'Please fill in all fields';
      this.render();
      this.setupEventListeners();
      return;
    }
    
    // Set loading state
    this.state.isLoggingIn = true;
    this.state.loginError = null;
    this.render();
    this.setupEventListeners();
    
    try {
      // Attempt login via auth manager
      await window.authManager.login(email, password);
      
      // Call the onLogin callback if provided
      if (typeof this.options.onLogin === 'function') {
        this.options.onLogin();
      }
      
      // Get redirect URL from query params or options
      const urlParams = new URLSearchParams(window.location.search);
      const redirectUrl = urlParams.get('redirect') || this.options.redirectUrl;
      
      // Redirect to dashboard or specified URL
      window.location.href = redirectUrl;
    } catch (error) {
      console.error('Login error:', error);
      this.state.loginError = error.message || 'Invalid email or password';
      this.state.isLoggingIn = false;
      this.render();
      this.setupEventListeners();
    }
  }
  
  async handleRegister() {
    // Get form values
    const name = document.getElementById('register-name').value;
    const email = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    
    // Validate
    if (!name || !email || !password) {
      this.state.registerError = 'Please fill in all fields';
      this.render();
      this.setupEventListeners();
      return;
    }
    
    // Password validation
    const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
    if (!passwordPattern.test(password)) {
      this.state.registerError = 'Password must be at least 8 characters and include uppercase, lowercase, and numbers';
      this.render();
      this.setupEventListeners();
      return;
    }
    
    // Set loading state
    this.state.isRegistering = true;
    this.state.registerError = null;
    this.render();
    this.setupEventListeners();
    
    try {
      // Attempt registration via auth manager
      await window.authManager.register(name, email, password);
      
      // Get redirect URL from query params or options
      const urlParams = new URLSearchParams(window.location.search);
      const redirectUrl = urlParams.get('redirect') || this.options.redirectUrl;
      
      // Redirect to dashboard or specified URL
      window.location.href = redirectUrl;
    } catch (error) {
      console.error('Registration error:', error);
      this.state.registerError = error.message || 'Registration failed. Please try again.';
      this.state.isRegistering = false;
      this.render();
      this.setupEventListeners();
    }
  }
  
  checkRedirectParam() {
    // If there's a 'tab' parameter in the URL, switch to that tab
    const urlParams = new URLSearchParams(window.location.search);
    const tabParam = urlParams.get('tab');
    
    if (tabParam && ['login', 'register'].includes(tabParam)) {
      this.switchTab(tabParam);
    }
  }
}

// Export the component
window.LoginForm = LoginForm; 