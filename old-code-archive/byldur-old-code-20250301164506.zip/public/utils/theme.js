/**
 * Theme management utility
 */
class ThemeManager {
  constructor() {
    this.theme = localStorage.getItem('byldur-theme') || 'light';
    this.init();
  }

  init() {
    // Apply theme on initialization
    this.applyTheme(this.theme);
    
    // Add event listeners to theme toggles
    document.addEventListener('DOMContentLoaded', () => {
      const themeToggles = document.querySelectorAll('.theme-toggle');
      themeToggles.forEach(toggle => {
        // Set initial state
        toggle.setAttribute('data-theme', this.theme);
        
        // Add click handler
        toggle.addEventListener('click', () => {
          const newTheme = this.theme === 'light' ? 'dark' : 'light';
          this.setTheme(newTheme);
          
          // Update all toggles
          themeToggles.forEach(t => {
            t.setAttribute('data-theme', newTheme);
          });
        });
      });
    });
  }

  applyTheme(theme) {
    if (theme === 'dark') {
      document.documentElement.setAttribute('data-theme', 'dark');
    } else {
      document.documentElement.removeAttribute('data-theme');
    }
    this.theme = theme;
    localStorage.setItem('byldur-theme', theme);
  }

  setTheme(theme) {
    this.applyTheme(theme);
  }

  toggleTheme() {
    const newTheme = this.theme === 'light' ? 'dark' : 'light';
    this.setTheme(newTheme);
    return newTheme;
  }

  getTheme() {
    return this.theme;
  }
}

// Initialize theme manager
const themeManager = new ThemeManager();

// Export for usage in other modules
window.themeManager = themeManager; 