/**
 * Authentication utility for handling user authentication across the app
 */
class AuthManager {
  constructor() {
    this.user = null;
    this.token = localStorage.getItem('byldur-token');
    this.init();
  }

  init() {
    if (this.token) {
      this.fetchUserInfo();
    }

    document.addEventListener('DOMContentLoaded', () => {
      // Handle logout buttons
      const logoutButtons = document.querySelectorAll('.logout-btn, #logout-link');
      logoutButtons.forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.preventDefault();
          this.logout();
        });
      });
    });
  }

  async login(email, password) {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ email, password })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Login failed');
      }

      const data = await response.json();
      this.setAuthData(data.token, data.user);
      return data.user;
    } catch (error) {
      throw error;
    }
  }

  async register(name, email, password) {
    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, email, password })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Registration failed');
      }

      const data = await response.json();
      this.setAuthData(data.token, data.user);
      return data.user;
    } catch (error) {
      throw error;
    }
  }

  logout() {
    localStorage.removeItem('byldur-token');
    this.user = null;
    this.token = null;
    
    // Redirect to login page
    window.location.href = '/login.html';
  }

  async fetchUserInfo() {
    try {
      const response = await fetch('/api/auth/me', {
        headers: {
          'Authorization': `Bearer ${this.token}`
        }
      });

      if (!response.ok) {
        if (response.status === 401) {
          // Token is invalid, clear it
          this.logout();
          return null;
        }
        throw new Error('Failed to fetch user info');
      }

      const userData = await response.json();
      this.user = userData;
      return userData;
    } catch (error) {
      console.error('Error fetching user info:', error);
      return null;
    }
  }

  setAuthData(token, user) {
    this.token = token;
    this.user = user;
    localStorage.setItem('byldur-token', token);
    
    // Update UI for the user
    this.updateUserUI();
  }
  
  updateUserUI() {
    if (!this.user) return;
    
    // Update username displays
    const usernameDisplays = document.querySelectorAll('#username-display, .username-display');
    usernameDisplays.forEach(element => {
      if (element) element.textContent = this.user.name;
    });
    
    // Update user email displays
    const emailDisplays = document.querySelectorAll('#email-display, .email-display');
    emailDisplays.forEach(element => {
      if (element) element.textContent = this.user.email;
    });
  }

  isAuthenticated() {
    return !!this.token;
  }

  getToken() {
    return this.token;
  }

  getUser() {
    return this.user;
  }

  getAuthHeader() {
    return {
      'Authorization': `Bearer ${this.token}`
    };
  }
  
  // Check if the current user should be redirected to login
  checkAuth(redirectToLogin = true) {
    if (!this.isAuthenticated()) {
      if (redirectToLogin) {
        window.location.href = `/login.html?redirect=${encodeURIComponent(window.location.pathname)}`;
      }
      return false;
    }
    return true;
  }
}

// Initialize and export
const authManager = new AuthManager();
window.authManager = authManager; 