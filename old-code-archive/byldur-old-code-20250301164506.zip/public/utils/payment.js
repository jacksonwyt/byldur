/**
 * Payment utility for handling Stripe payments 
 */
class PaymentManager {
  constructor() {
    this.stripe = null;
    this.elements = null;
    this.cardElement = null;
    this.initialized = false;
  }

  /**
   * Initialize Stripe with the publishable key
   * This should be called before using any other methods
   */
  async init(publishableKey) {
    if (!window.Stripe) {
      // Load Stripe.js if not already available
      await this.loadScript('https://js.stripe.com/v3/');
    }
    
    this.stripe = window.Stripe(publishableKey);
    this.initialized = true;
    return this;
  }
  
  /**
   * Initialize a card element in the specified container
   * @param {string} elementId - The ID of the container element
   * @param {Object} options - Options for the card element
   * @returns {Object} - The card element instance
   */
  createCardElement(elementId, options = {}) {
    if (!this.initialized) {
      throw new Error('PaymentManager must be initialized before creating elements');
    }
    
    const defaultOptions = {
      style: {
        base: {
          color: '#32325d',
          fontFamily: 'var(--font-family)',
          fontSmoothing: 'antialiased',
          fontSize: '16px',
          '::placeholder': {
            color: '#aab7c4'
          }
        },
        invalid: {
          color: '#fa755a',
          iconColor: '#fa755a'
        }
      }
    };
    
    this.elements = this.stripe.elements();
    this.cardElement = this.elements.create('card', { ...defaultOptions, ...options });
    this.cardElement.mount(`#${elementId}`);
    
    return this.cardElement;
  }
  
  /**
   * Process a payment with the provided payment method
   * @param {string} clientSecret - The client secret from the PaymentIntent
   * @param {Object} billingDetails - The billing details for the payment
   * @returns {Promise} - A promise that resolves with the payment result
   */
  async processPayment(clientSecret, billingDetails = {}) {
    if (!this.initialized || !this.cardElement) {
      throw new Error('Card element must be created before processing payment');
    }
    
    const result = await this.stripe.confirmCardPayment(clientSecret, {
      payment_method: {
        card: this.cardElement,
        billing_details: billingDetails
      }
    });
    
    return result;
  }
  
  /**
   * Process a subscription with the provided payment method
   * @param {string} clientSecret - The client secret from the PaymentIntent
   * @param {Object} billingDetails - The billing details for the subscription
   * @returns {Promise} - A promise that resolves with the subscription result
   */
  async processSubscription(clientSecret, billingDetails = {}) {
    if (!this.initialized || !this.cardElement) {
      throw new Error('Card element must be created before processing subscription');
    }
    
    const result = await this.stripe.confirmCardSetup(clientSecret, {
      payment_method: {
        card: this.cardElement,
        billing_details: billingDetails
      }
    });
    
    return result;
  }
  
  /**
   * Create a payment method from the card element
   * @param {Object} billingDetails - The billing details for the payment method
   * @returns {Promise} - A promise that resolves with the payment method
   */
  async createPaymentMethod(billingDetails = {}) {
    if (!this.initialized || !this.cardElement) {
      throw new Error('Card element must be created before creating payment method');
    }
    
    const result = await this.stripe.createPaymentMethod({
      type: 'card',
      card: this.cardElement,
      billing_details: billingDetails
    });
    
    return result;
  }
  
  /**
   * Redirect to Stripe Checkout
   * @param {string} sessionId - The Checkout Session ID
   * @returns {Promise} - A promise that resolves when the redirect is complete
   */
  async redirectToCheckout(sessionId) {
    if (!this.initialized) {
      throw new Error('PaymentManager must be initialized before redirecting to checkout');
    }
    
    const result = await this.stripe.redirectToCheckout({
      sessionId
    });
    
    if (result.error) {
      throw new Error(result.error.message);
    }
    
    return result;
  }
  
  /**
   * Load a script asynchronously
   * @private
   * @param {string} url - The URL of the script to load
   * @returns {Promise} - A promise that resolves when the script is loaded
   */
  loadScript(url) {
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = url;
      script.onload = resolve;
      script.onerror = () => reject(new Error(`Failed to load script: ${url}`));
      document.head.appendChild(script);
    });
  }
}

// Initialize and export
const paymentManager = new PaymentManager();
window.paymentManager = paymentManager; 